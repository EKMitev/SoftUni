package needForSpeed;

public class Main {
    public static void main(String[] args) {
        FamilyCar familyCar = new FamilyCar(4, 10);

        System.out.println(familyCar.getFuelConsumption());

    }
}