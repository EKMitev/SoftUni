package WildFarm;

public abstract class Food {
    public Food(Integer quantity) {
        this.quantity = quantity;
    }

    protected Integer quantity;
}
